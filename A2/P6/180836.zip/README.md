## Homework 2 Problem 6 Submission
### Author: Utkarsh Gupta 
### Language: Python 3
### File Name: code.py
#### Libraries Required: numpy, matplotlib and sklearn

* Replace the path to the Dataset on Line number ```5``` before running.
* To run, execute: ``` python3 code.py ``` in your command-line.
* Once the program is run, 3 plots will pop up one after another.
* First Plot is for Generative Classifiation with different covariances for the 2 classes.
* Second Plot is for Generative Classifiation with same covariances for the 2 classes.
* Third Plot is for SVM Classification with Linear Kernel